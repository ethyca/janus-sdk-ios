/**
 * Core bridge functionality between native iOS and JavaScript
 * Handles event listening and message passing
 */
(function() {
    if (window.__janusBridge_bridgeInstalled) {
        return;
    }
    window.__janusBridge_bridgeInstalled = true;

    // Map of all FidesJS events we want to listen for
    const fidesEvents = [
        'FidesInitializing',
        'FidesInitialized',
        'FidesUIShown',
        'FidesUIChanged',
        'FidesModalClosed',
        'FidesUpdating',
        'FidesUpdated'
    ];

    function sendToNative(eventType, detail) {
        if (window.JanusSDK && window.JanusSDK.event) {
            window.JanusSDK.event(eventType, detail);
        } else {
            window.Janus.log(`window.JanusSDK.event is not defined for event: ${eventType}`, null, 'error');
        }
    }

    // Add listeners for each FidesJS event
    fidesEvents.forEach(eventType => {
        window.addEventListener(eventType, event => {
            sendToNative(eventType, event.detail || {});
        });
    });

    // FidesJS marks each event just before dispatching it. Fides.initialized alone isn't enough:
    // it turns true when saved consent loads, before FidesInitialized fires in the default mode.
    function fidesInitializedWasDispatched() {
        const performance = window.performance;
        return !!performance &&
            typeof performance.getEntriesByName === 'function' &&
            performance.getEntriesByName('FidesInitialized', 'mark').length > 0;
    }

    // A bridge injected after FidesJS initialised missed FidesInitialized, so send one from the current state.
    // The React Native bundle runs the shared scripts as one, where a throw here would stop the later ones.
    try {
        const fides = window.Fides;
        if (fides && fides.initialized === true && fidesInitializedWasDispatched()) {
            const extraDetails = { replayed: true };
            if (typeof fides.shouldShowExperience === 'function') {
                extraDetails.shouldShowExperience = fides.shouldShowExperience();
            }
            if (fides.fides_meta && fides.fides_meta.consentMethod) {
                extraDetails.consentMethod = fides.fides_meta.consentMethod;
            }
            sendToNative('FidesInitialized', {
                // Fides.consent is a Proxy, which WKWebView's postMessage silently drops
                consent: fides.consent && { ...fides.consent },
                fides_meta: fides.fides_meta,
                identity: fides.identity,
                fides_string: fides.fides_string,
                tcf_consent: fides.tcf_consent,
                extraDetails: extraDetails
            });
        }
    } catch (e) {
        console.error('Janus bridge could not replay FidesInitialized', e);
    }
})();
