/**
 * Core bridge functionality between native iOS and JavaScript
 * Handles event listening and message passing
 */
(function() {
    // Map of all FidesJS events we want to listen for
    const fidesEvents = [
        'FidesInitializing',
        'FidesInitialized',
        'FidesUIShown',
        'FidesUIChanged', 
        'FidesModalClosed',
        'FidesUpdating',
        'FidesUpdated'
    ];
    
    // Add listeners for each FidesJS event
    fidesEvents.forEach(eventType => {
        window.addEventListener(eventType, event => {
            // Create message to send to native code
            const message = {
                type: eventType,
                data: event.detail || {}
            };
            
            // Send to native through webkit message handler
            window.webkit.messageHandlers.fidesJSBridge.postMessage(message);
        });
    });
})(); 