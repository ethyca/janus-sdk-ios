//
//  JanusSDK.h
//  JanusSDK
//
//  Created by Thabo Fletcher on 3/4/25.
//

#import <Foundation/Foundation.h>

//! Project version number for JanusSDK.
FOUNDATION_EXPORT double JanusSDKVersionNumber;

//! Project version string for JanusSDK.
FOUNDATION_EXPORT const unsigned char JanusSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JanusSDK/PublicHeader.h>


